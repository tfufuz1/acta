// FILE-CONTEXT Header (Format v3)
// ZWECK: Continuous event stream abstractions delivering telemetry/trigger events to agents.
// INVARIANTEN: Enforces MAX_EVENT_SOURCE_CAPACITY (10,000) on pending queue and event list; validates event source string.
// NICHT-OFFENSICHTLICH: PollingDocumentEventSource performs delta scanning via scan_prefix_at; drops over-capacity events gracefully.
// HOTSPOTS: BackgroundEvent::try_new (ll. 30-60), PollingDocumentEventSource::next_event (ll. 120-175).
// STAND: TS:2026-09-01T23:11:04Z (SESSION: 5a38054a)

//! Continuous event source abstractions for background telemetry and triggers.
//!
//! Provides `EventSource` trait and concrete implementations (`PollingDocumentEventSource`, `VecEventSource`).

// =========================================================================
// SECTION: Continuous Event Sources & Telemetry
// =========================================================================
// ANCHOR[contextra-agent:event-source-primitives]


use crate::context::MAX_ID_LEN;
use contextra_db::Collection;
use contextra_ports::{BoxFuture, StorageEngine};
use contextra_types::{ContextraError, Result};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, VecDeque};
use std::sync::Arc;
use std::time::Duration;

/// Maximum allowed events in pending event buffers to prevent memory exhaustion.
pub const MAX_EVENT_SOURCE_CAPACITY: usize = 10_000;

/// Background telemetry/trigger event delivered to the agent context.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BackgroundEvent {
    /// Payload associated with the background telemetry event.
    pub payload: serde_json::Value,
    /// Origin identifier of the event producer.
    pub source: String,
    /// Storage sequence number at which this event was observed.
    pub observed_at_seq: u64,
}

impl BackgroundEvent {
    /// Constructs a `BackgroundEvent` with input validation on the source identifier.
    // AI-TAG[HARDENING][CRITICAL] RESOLVED: Validates non-empty event source to prevent silent telemetry attribution loss. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f)
    pub fn try_new(
        payload: serde_json::Value,
        source: impl Into<String>,
        observed_at_seq: u64,
    ) -> Result<Self> {
        let source_str = source.into();
        if source_str.trim().is_empty() {
            return Err(contextra_types::ContextraError::InvalidInput(
                "BackgroundEvent source must not be empty".to_string(),
            ));
        }
        if source_str.len() > MAX_ID_LEN {
            return Err(contextra_types::ContextraError::InvalidInput(format!(
                "BackgroundEvent source length {} exceeds maximum allowed length of {}",
                source_str.len(),
                MAX_ID_LEN
            )));
        }
        if source_str.contains('\0') {
            return Err(contextra_types::ContextraError::InvalidInput(
                "BackgroundEvent source cannot contain null bytes".to_string(),
            ));
        }
        Ok(Self {
            payload,
            source: source_str,
            observed_at_seq,
        })
    }

    /// Legacy constructor for `BackgroundEvent` (deprecated).
    #[deprecated(note = "Use try_new instead to handle validation errors without panicking")]
    pub fn new(
        payload: serde_json::Value,
        source: impl Into<String>,
        observed_at_seq: u64,
    ) -> Self {
        let raw_source = source.into();
        Self::try_new(payload.clone(), &raw_source, observed_at_seq).unwrap_or_else(|_| Self {
            payload,
            source: if raw_source.trim().is_empty() {
                "unknown".to_string()
            } else {
                raw_source
                    .chars()
                    .filter(|c| *c != '\0')
                    .take(MAX_ID_LEN)
                    .collect()
            },
            observed_at_seq,
        })
    }
}

/// Dynamic event source delivering continuous background events.
pub trait EventSource: Send + Sync {
    /// Fetches the next available background event.
    /// Returns `Ok(Some(event))` when an event is ready, `Ok(None)` if no event is currently pending.
    fn next_event<'a>(&'a mut self) -> BoxFuture<'a, Result<Option<BackgroundEvent>>>;

    /// Indicates whether the event source is permanently exhausted.
    /// Always returns `false` for continuous/always-on producers.
    fn is_exhausted(&self) -> bool {
        false
    }

    /// Waits until a new event is likely available or the timeout expires.
    /// Default implementation: short sleep fallback for polling-based sources.
    /// Implementations with push notifications (e.g. `tokio::sync::Notify`) should override
    /// this method to wait on signals instead of polling.
    fn wait_for_event<'a>(&'a self) -> BoxFuture<'a, ()> {
        Box::pin(async move {
            tokio::time::sleep(Duration::from_millis(50)).await;
        })
    }
}

/// Maximum capacity for pending background telemetry events queue before dropping or rejecting.
pub const MAX_PENDING_EVENTS_CAPACITY: usize = 10_000;

/// Concrete `EventSource` that periodically polls `Collection` storage sequence numbers,
/// using `scan_prefix_at` for snapshot delta calculation to emit document changes.
pub struct PollingDocumentEventSource<S: StorageEngine> {
    collection: Arc<Collection<S>>,
    last_seen_seq: u64,
    poll_interval: Duration,
    pending_events: VecDeque<BackgroundEvent>,
}

impl<S: StorageEngine> PollingDocumentEventSource<S> {
    /// Creates a new `PollingDocumentEventSource` watching the specified collection.
    pub fn new(collection: Arc<Collection<S>>, poll_interval: Duration) -> Self {
        Self::with_capacity(collection, poll_interval, MAX_PENDING_EVENTS_CAPACITY)
    }

    /// Creates a new `PollingDocumentEventSource` with specified maximum queue capacity bound.
    // AI-TAG[HARDENING][CRITICAL] RESOLVED: Enforces bounded event queue capacity to guard against unbounded memory growth. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f)
    pub fn with_capacity(
        collection: Arc<Collection<S>>,
        poll_interval: Duration,
        _max_pending_capacity: usize,
    ) -> Self {
        Self {
            collection,
            last_seen_seq: 0,
            poll_interval,
            pending_events: VecDeque::new(),
        }
    }

    /// Configures the initial last seen sequence number (Builder pattern).
    pub fn with_last_seen_seq(mut self, last_seen_seq: u64) -> Self {
        self.last_seen_seq = last_seen_seq;
        self
    }

    /// Returns the configured polling interval duration.
    pub fn poll_interval(&self) -> Duration {
        self.poll_interval
    }
}

impl<S: StorageEngine> EventSource for PollingDocumentEventSource<S> {
    fn next_event<'a>(&'a mut self) -> BoxFuture<'a, Result<Option<BackgroundEvent>>> {
        Box::pin(async move {
            if let Some(event) = self.pending_events.pop_front() {
                return Ok(Some(event));
            }

            let current_seq = self.collection.storage().last_seq_no().await?;

            if current_seq > self.last_seen_seq {
                let prefix = self.collection.user_key_prefix();
                let current_entries = self
                    .collection
                    .storage()
                    .scan_prefix_at(&prefix, current_seq)
                    .await?;

                let previous_entries: BTreeMap<Vec<u8>, Vec<u8>> = if self.last_seen_seq > 0 {
                    self.collection
                        .storage()
                        .scan_prefix_at(&prefix, self.last_seen_seq)
                        .await?
                        .into_iter()
                        .collect()
                } else {
                    BTreeMap::new()
                };

                for (key, val) in current_entries {
                    if previous_entries.get(&key) != Some(&val) {
                        if self.pending_events.len() >= MAX_EVENT_SOURCE_CAPACITY {
                            tracing::warn!("PollingDocumentEventSource: Pending events queue capacity limit ({}) reached, dropping remaining events", MAX_EVENT_SOURCE_CAPACITY);
                            break;
                        }
                        let payload = serde_json::from_slice(&val).unwrap_or_else(|_| {
                            serde_json::json!({
                                "raw": String::from_utf8_lossy(&val),
                                "key": String::from_utf8_lossy(&key)
                            })
                        });
                        self.pending_events.push_back(BackgroundEvent {
                            payload,
                            source: format!("collection:{}", self.collection.name()),
                            observed_at_seq: current_seq,
                        });
                    }
                }

                self.last_seen_seq = current_seq;

                if let Some(event) = self.pending_events.pop_front() {
                    return Ok(Some(event));
                }
            }

            Ok(None)
        })
    }

    fn wait_for_event<'a>(&'a self) -> BoxFuture<'a, ()> {
        Box::pin(async move {
            tokio::time::sleep(self.poll_interval).await;
        })
    }
}

/// Trivial mock/static `EventSource` that reads from a fixed list of `BackgroundEvent`s.
pub struct VecEventSource {
    events: VecDeque<BackgroundEvent>,
}

impl VecEventSource {
    /// Attempts to construct a `VecEventSource` with a capacity check.
    pub fn try_new(events: Vec<BackgroundEvent>) -> Result<Self> {
        if events.len() > MAX_EVENT_SOURCE_CAPACITY {
            return Err(ContextraError::MemoryBudgetExceeded {
                used_mb: ((events.len() * std::mem::size_of::<BackgroundEvent>()) / (1024 * 1024))
                    as u64,
                limit_mb: MAX_EVENT_SOURCE_CAPACITY as u64,
            });
        }
        Ok(Self {
            events: events.into(),
        })
    }
}

impl EventSource for VecEventSource {
    fn next_event<'a>(&'a mut self) -> BoxFuture<'a, Result<Option<BackgroundEvent>>> {
        Box::pin(async move { Ok(self.events.pop_front()) })
    }

    fn is_exhausted(&self) -> bool {
        self.events.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_background_event_validation() {
        assert!(BackgroundEvent::try_new(serde_json::json!({}), "valid_source", 1).is_ok());

        assert!(matches!(
            BackgroundEvent::try_new(serde_json::json!({}), "", 1),
            Err(ContextraError::InvalidInput(_))
        ));

        assert!(matches!(
            BackgroundEvent::try_new(serde_json::json!({}), "source\0null", 1),
            Err(ContextraError::InvalidInput(_))
        ));

        let huge_source = "s".repeat(300);
        assert!(matches!(
            BackgroundEvent::try_new(serde_json::json!({}), &huge_source, 1),
            Err(ContextraError::InvalidInput(_))
        ));
    }

    #[test]
    fn test_vec_event_source_capacity_limit() {
        let mut events = Vec::new();
        for i in 0..10_001 {
            if let Ok(event) = BackgroundEvent::try_new(serde_json::json!({}), "source", i) {
                events.push(event);
            }
        }

        assert!(matches!(
            VecEventSource::try_new(events),
            Err(ContextraError::MemoryBudgetExceeded { .. })
        ));
    }
}

// !SECTION
