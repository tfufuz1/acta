// FILE-CONTEXT Header (Format v3)
// ZWECK: Workflow execution state context carrying task ID, budget, and memory.
// INVARIANTEN: Task ID & node ID must be non-empty, <=256 bytes, null-byte free; event history capped at 10,000 items.
// NICHT-OFFENSICHTLICH: attach_event evicts oldest event to strictly limit memory growth.
// HOTSPOTS: validate_task_id/validate_node_id (ll. 20-55), attach_event (ll. 140-155).
// STAND: TS:2026-09-01T23:11:04Z (SESSION: 5a38054a)

//! Operational context for an agent workflow execution.
//!
//! Carries task identity, graph position, token budget, DB references, and
//! accumulated step memory across the entire lifecycle of a single workflow run.

// =========================================================================
// SECTION: AgentContext & Execution State
// =========================================================================
// ANCHOR[contextra-agent:context-primitives]


use contextra_db::{Collection, Contextra};
use contextra_types::error::{CacheDirective, StepId};
use contextra_types::{ContextraError, Result, TokenBudget};
use std::collections::{BTreeMap, VecDeque};
use std::sync::Arc;

/// Maximum allowed length in bytes for task IDs and node IDs.
pub const MAX_ID_LEN: usize = 256;

/// Maximum allowed telemetry events stored in memory history.
pub const MAX_TELEMETRY_EVENTS: usize = 10_000;

/// Validates a task identifier to ensure it is non-empty, <= 256 bytes, and contains no null bytes.
pub fn validate_task_id(task_id: &str) -> Result<()> {
    if task_id.trim().is_empty() {
        return Err(ContextraError::InvalidInput(
            "task_id cannot be empty".to_string(),
        ));
    }
    if task_id.len() > MAX_ID_LEN {
        return Err(ContextraError::InvalidInput(format!(
            "task_id length {} exceeds maximum allowed length of {}",
            task_id.len(),
            MAX_ID_LEN
        )));
    }
    if task_id.contains('\0') {
        return Err(ContextraError::InvalidInput(
            "task_id cannot contain null bytes".to_string(),
        ));
    }
    Ok(())
}

/// Validates a node identifier to ensure it is non-empty, <= 256 bytes, and contains no null bytes.
pub fn validate_node_id(node_id: &str) -> Result<()> {
    if node_id.trim().is_empty() {
        return Err(ContextraError::InvalidInput(
            "node_id cannot be empty".to_string(),
        ));
    }
    if node_id.len() > MAX_ID_LEN {
        return Err(ContextraError::InvalidInput(format!(
            "node_id length {} exceeds maximum allowed length of {}",
            node_id.len(),
            MAX_ID_LEN
        )));
    }
    if node_id.contains('\0') {
        return Err(ContextraError::InvalidInput(
            "node_id cannot contain null bytes".to_string(),
        ));
    }
    Ok(())
}

/// Operational status of an agent workflow.
#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum AgentStatus {
    /// Agent workflow has been initialized but is not actively running.
    Idle,
    /// Agent workflow is actively executing graph step transitions.
    Running,
    /// Agent workflow reached a terminal `End` node successfully.
    Completed,
    /// Agent workflow encountered an unrecoverable step or system failure.
    Failed,
}

/// Operational context spanning the entire workflow execution.
pub struct AgentContext {
    /// Unique task identifier for this agent workflow run.
    pub task_id: String,
    /// Active graph node identifier currently being evaluated.
    pub current_node: String,
    /// Total number of workflow steps completed so far.
    pub step_count: u64,
    /// Contextra DB handle providing collection storage.
    pub db: Arc<Contextra>,
    /// State storage collection where workflow history and audit traces are persisted.
    pub state_collection: Arc<Collection>,
    /// Token budget manager enforcing execution cost limits.
    pub budget: TokenBudget,
    /// Active operational status of the workflow execution.
    pub status: AgentStatus,
    /// Active cache directive for the current workflow step.
    pub current_cache_directive: CacheDirective,
    /// History of cache directives set per step ID.
    pub step_directives: BTreeMap<u64, CacheDirective>,
    /// Accumulates results and state transfers between steps.
    pub memory: BTreeMap<String, serde_json::Value>,
    /// History of attached background telemetry events.
    pub events: VecDeque<crate::event_source::BackgroundEvent>,
    /// Offene Routing-Entscheidung, deren Ergebnis nach Tool-Ausführung zurückgemeldet werden soll.
    pub pending_routing_decision: Option<(
        Arc<contextra_router::DefaultRouterEngine>,
        contextra_router::DecisionId,
    )>,
    /// Optionales CLM Scratchpad für temporären Arbeitskontext.
    pub clm_scratchpad: Option<crate::clm_scratchpad::ClmScratchpad>,
    /// Neueste ScratchpadCheckpoint-Zusammenfassung nach einem Subgoal-Reset.
    pub latest_scratchpad_checkpoint: Option<crate::clm_scratchpad::ScratchpadCheckpoint>,
}

impl AgentContext {
    /// Tries to construct a new [`AgentContext`], performing input validation on task ID and start node.
    // AI-TAG[HARDENING][CRITICAL] RESOLVED: Validates non-empty input parameters for agent workflow context initialization. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f)
    pub fn try_new(
        task_id: impl Into<String>,
        start_node: impl Into<String>,
        db: Arc<Contextra>,
        state_collection: Arc<Collection>,
        budget: TokenBudget,
    ) -> contextra_types::Result<Self> {
        let task_id_str = task_id.into();
        let start_node_str = start_node.into();

        if task_id_str.trim().is_empty() {
            return Err(contextra_types::ContextraError::InvalidInput(
                "AgentContext task_id must not be empty".to_string(),
            ));
        }

        if start_node_str.trim().is_empty() {
            return Err(contextra_types::ContextraError::InvalidInput(
                "AgentContext start_node must not be empty".to_string(),
            ));
        }

        Ok(Self {
            task_id: task_id_str,
            current_node: start_node_str,
            step_count: 0,
            db,
            state_collection,
            budget,
            status: AgentStatus::Idle,
            current_cache_directive: CacheDirective::Auto,
            step_directives: BTreeMap::new(),
            memory: BTreeMap::new(),
            events: VecDeque::new(),
            pending_routing_decision: None,
            clm_scratchpad: None,
            latest_scratchpad_checkpoint: None,
        })
    }

    /// Attaches an optional [`ClmScratchpad`](crate::clm_scratchpad::ClmScratchpad) to the agent context (Builder pattern).
    pub fn with_clm_scratchpad(mut self, scratchpad: crate::clm_scratchpad::ClmScratchpad) -> Self {
        self.clm_scratchpad = Some(scratchpad);
        self
    }

    /// Sets the active cache directive for the context.
    pub fn set_cache_directive(&mut self, directive: CacheDirective) {
        self.current_cache_directive = directive;
    }

    /// Returns the active cache directive for the context.
    pub fn get_cache_directive(&self) -> &CacheDirective {
        &self.current_cache_directive
    }

    /// Records a cache directive for a specific step ID.
    pub fn set_step_cache_directive(&mut self, step_id: StepId, directive: CacheDirective) {
        self.current_cache_directive = directive.clone();
        self.step_directives.insert(step_id.inner(), directive);
    }

    /// Returns the appropriate `CacheDirective` for a workflow node / prompt role.
    pub fn directive_for_node(&self, node_id: &str, step_id: StepId) -> CacheDirective {
        let lower = node_id.to_lowercase();
        if lower.contains("system") || lower.contains("prompt") {
            CacheDirective::Pin { ttl: None }
        } else if lower.contains("reasoning") || lower.contains("transient") {
            CacheDirective::ReleaseAfterStep { step_id }
        } else {
            CacheDirective::Auto
        }
    }

    /// Integrates a background telemetry event into the agent context memory and history.
    ///
    /// Maintains event history capacity bounded at `MAX_TELEMETRY_EVENTS` to prevent memory exhaustion.
    pub fn attach_event(&mut self, event: crate::event_source::BackgroundEvent) {
        if let Ok(val) = serde_json::to_value(&event) {
            self.memory.insert("latest_event".to_string(), val);
        }
        if self.events.len() >= MAX_TELEMETRY_EVENTS {
            self.events.pop_front(); // Evict oldest event to cap memory usage
        }
        self.events.push_back(event);
    }

    /// Returns the step count to be used for a recovery retry after a partial step failure.
    pub fn next_retry_step_count(&self) -> u64 {
        self.step_count + 1
    }

    /// Integrates a background telemetry event with an explicit capacity check.
    pub fn try_attach_event(&mut self, event: crate::event_source::BackgroundEvent) -> Result<()> {
        if self.events.len() >= MAX_TELEMETRY_EVENTS {
            let current_count = self.events.len();
            let max_event_count = MAX_TELEMETRY_EVENTS;
            return Err(ContextraError::InvalidInput(format!(
                "Telemetry event buffer limit reached: {} events (max {})",
                current_count, max_event_count
            )));
        }
        self.attach_event(event);
        Ok(())
    }
}

/// Agent execution engine helper managing per-step cache directives during workflow execution.
#[derive(Debug, Clone, Default)]
pub struct AgentEngine {
    /// Active cache directive set during step execution.
    pub current_directive: CacheDirective,
}

impl AgentEngine {
    /// Constructs a new `AgentEngine`.
    pub fn new() -> Self {
        Self {
            current_directive: CacheDirective::Auto,
        }
    }

    /// Determines the appropriate `CacheDirective` for a node ID / prompt role.
    ///
    /// - System prompt nodes -> `CacheDirective::Pin { ttl: None }`
    /// - Transient reasoning steps -> `CacheDirective::ReleaseAfterStep { step_id }`
    /// - Default -> `CacheDirective::Auto`
    pub fn directive_for_step(&self, node_id: &str, step_id: StepId) -> CacheDirective {
        let lower = node_id.to_lowercase();
        if lower.contains("system") || lower.contains("prompt") {
            CacheDirective::Pin { ttl: None }
        } else if lower.contains("reasoning") || lower.contains("transient") {
            CacheDirective::ReleaseAfterStep { step_id }
        } else {
            CacheDirective::Auto
        }
    }

    /// Executes step configuration, updating context with per-step cache directives.
    pub fn run(
        &mut self,
        ctx: &mut AgentContext,
        step_id: StepId,
        node_id: &str,
    ) -> CacheDirective {
        let directive = self.directive_for_step(node_id, step_id);
        self.current_directive = directive.clone();
        ctx.set_step_cache_directive(step_id, directive.clone());
        directive
    }
}

#[cfg(test)]
#[allow(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::cast_sign_loss,
    clippy::disallowed_methods,
    clippy::unreachable,
    clippy::indexing_slicing,
    clippy::cast_possible_truncation
)]
mod tests {
    use super::*;

    #[test]
    fn test_agent_context_cache_directives() {
        let ctx_stub = AgentEngine::new();
        let step_id = StepId::new(42);

        let system_dir = ctx_stub.directive_for_step("system_prompt_node", step_id);
        assert!(matches!(system_dir, CacheDirective::Pin { ttl: None }));

        let transient_dir = ctx_stub.directive_for_step("reasoning_step", step_id);
        assert!(matches!(
            transient_dir,
            CacheDirective::ReleaseAfterStep { .. }
        ));

        let default_dir = ctx_stub.directive_for_step("standard_step", step_id);
        assert_eq!(default_dir, CacheDirective::Auto);
    }

    #[tokio::test]
    async fn test_agent_context_with_clm_scratchpad() -> contextra_types::Result<()> {
        let temp_dir = tempfile::TempDir::new()?;
        let config = contextra_db::ContextraConfig::default();
        let db =
            Arc::new(contextra_db::Contextra::open_with_config(temp_dir.path(), config).await?);
        let state_coll = db.collection("test_clm").await?;

        let vault_config = contextra_db::volatile_vault::VaultConfig {
            max_capacity_bytes: 1024 * 1024,
            attempt_mlock: false,
        };
        let scratchpad =
            crate::clm_scratchpad::ClmScratchpad::new("task-clm".to_string(), vault_config);

        let ctx = AgentContext::try_new(
            "task-clm",
            "start",
            db,
            state_coll,
            TokenBudget::new(1000, 0),
        )?
        .with_clm_scratchpad(scratchpad);

        assert!(ctx.clm_scratchpad.is_some());
        assert_eq!(
            ctx.clm_scratchpad.as_ref().map(|s| s.task_id()),
            Some("task-clm")
        );
        Ok(())
    }

    #[test]
    fn test_validate_task_id_guards() {
        assert!(validate_task_id("valid-task-123").is_ok());
        assert!(matches!(
            validate_task_id(""),
            Err(ContextraError::InvalidInput(_))
        ));
        assert!(matches!(
            validate_task_id("task\0with-null"),
            Err(ContextraError::InvalidInput(_))
        ));
        let oversized = "a".repeat(257);
        assert!(matches!(
            validate_task_id(&oversized),
            Err(ContextraError::InvalidInput(_))
        ));
    }

    #[test]
    fn test_validate_node_id_guards() {
        assert!(validate_node_id("valid-node").is_ok());
        assert!(matches!(
            validate_node_id(""),
            Err(ContextraError::InvalidInput(_))
        ));
        assert!(matches!(
            validate_node_id("node\0null"),
            Err(ContextraError::InvalidInput(_))
        ));
        let oversized = "n".repeat(257);
        assert!(matches!(
            validate_node_id(&oversized),
            Err(ContextraError::InvalidInput(_))
        ));
    }

    #[test]
    fn test_agent_context_telemetry_event_capacity_cap() {
        let dummy_payload = serde_json::json!({"test": 1});
        let mut attached_deque = VecDeque::new();
        for i in 0..10_005 {
            let ev = crate::event_source::BackgroundEvent {
                payload: dummy_payload.clone(),
                source: "test_source".to_string(),
                observed_at_seq: i as u64,
            };
            if attached_deque.len() >= MAX_TELEMETRY_EVENTS {
                attached_deque.pop_front();
            }
            attached_deque.push_back(ev);
        }

        assert_eq!(attached_deque.len(), 10_000);
        assert_eq!(
            attached_deque.back().map(|e| e.observed_at_seq),
            Some(10_004)
        );
    }

    #[tokio::test]
    async fn test_agent_context_fifo_eviction() -> contextra_types::Result<()> {
        let temp_dir = tempfile::TempDir::new()?;
        let config = contextra_db::ContextraConfig::default();
        let db =
            Arc::new(contextra_db::Contextra::open_with_config(temp_dir.path(), config).await?);
        let state_coll = db.collection("test_fifo").await?;
        let mut ctx = AgentContext::try_new(
            "test_fifo_task",
            "start",
            db,
            state_coll,
            TokenBudget::new(1000, 0),
        )?;

        let extra_events = 50;
        let total = MAX_TELEMETRY_EVENTS + extra_events;
        for i in 0..total {
            let ev = crate::event_source::BackgroundEvent {
                payload: serde_json::json!({ "seq": i }),
                source: "test_source".to_string(),
                observed_at_seq: i as u64,
            };
            ctx.attach_event(ev);
        }

        assert_eq!(ctx.events.len(), MAX_TELEMETRY_EVENTS);
        // The first remaining event in deque should have observed_at_seq = 50 (oldest 50 evicted)
        assert_eq!(
            ctx.events.front().map(|e| e.observed_at_seq),
            Some(extra_events as u64)
        );
        assert_eq!(
            ctx.events.back().map(|e| e.observed_at_seq),
            Some((total - 1) as u64)
        );
        Ok(())
    }

    #[tokio::test]
    async fn test_try_attach_event_error_message_unit() -> contextra_types::Result<()> {
        let temp_dir = tempfile::TempDir::new()?;
        let config = contextra_db::ContextraConfig::default();
        let db =
            Arc::new(contextra_db::Contextra::open_with_config(temp_dir.path(), config).await?);
        let state_coll = db.collection("test_try_attach").await?;
        let mut ctx = AgentContext::try_new(
            "test_try_attach_task",
            "start",
            db,
            state_coll,
            TokenBudget::new(1000, 0),
        )?;

        for i in 0..MAX_TELEMETRY_EVENTS {
            let ev = crate::event_source::BackgroundEvent {
                payload: serde_json::json!({ "seq": i }),
                source: "test_source".to_string(),
                observed_at_seq: i as u64,
            };
            ctx.attach_event(ev);
        }

        let overflow_ev = crate::event_source::BackgroundEvent {
            payload: serde_json::json!({ "overflow": true }),
            source: "test_source".to_string(),
            observed_at_seq: 99_999,
        };

        let res = ctx.try_attach_event(overflow_ev);
        assert!(res.is_err());
        let err_msg = match res {
            Err(e) => e.to_string(),
            Ok(_) => unreachable!(),
        };
        assert!(
            err_msg.contains("Telemetry event buffer limit reached"),
            "Expected 'Telemetry event buffer limit reached' in err_msg, got: {}",
            err_msg
        );
        assert!(
            err_msg.contains("events"),
            "Expected unit 'events' in err_msg, got: {}",
            err_msg
        );
        assert!(
            !err_msg.contains("MB"),
            "Err msg must not contain misleading 'MB' unit, got: {}",
            err_msg
        );
        Ok(())
    }

    #[tokio::test]
    async fn test_telemetry_100k_insertions_and_amortized_performance(
    ) -> contextra_types::Result<()> {
        let temp_dir = tempfile::TempDir::new()?;
        let config = contextra_db::ContextraConfig::default();
        let db =
            Arc::new(contextra_db::Contextra::open_with_config(temp_dir.path(), config).await?);
        let state_coll = db.collection("test_100k_bench").await?;
        let mut ctx = AgentContext::try_new(
            "test_100k_task",
            "start",
            db,
            state_coll,
            TokenBudget::new(1000, 0),
        )?;

        let total_insertions = 100_000;
        let chunk_size = 50_000;

        let t1_start = std::time::Instant::now();
        for i in 0..chunk_size {
            let ev = crate::event_source::BackgroundEvent {
                payload: serde_json::json!({ "i": i }),
                source: "bench_source".to_string(),
                observed_at_seq: i as u64,
            };
            ctx.attach_event(ev);
        }
        let chunk1_duration = t1_start.elapsed();

        let t2_start = std::time::Instant::now();
        for i in chunk_size..total_insertions {
            let ev = crate::event_source::BackgroundEvent {
                payload: serde_json::json!({ "i": i }),
                source: "bench_source".to_string(),
                observed_at_seq: i as u64,
            };
            ctx.attach_event(ev);
        }
        let chunk2_duration = t2_start.elapsed();

        // (a) Capacity is strictly capped at MAX_TELEMETRY_EVENTS (10,000)
        assert_eq!(
            ctx.events.len(),
            MAX_TELEMETRY_EVENTS,
            "Total events in deque must be strictly bounded at {}",
            MAX_TELEMETRY_EVENTS
        );

        // (b) FIFO eviction correctly retained the 10,000 youngest events
        let front_seq = ctx.events.front().map(|e| e.observed_at_seq);
        let back_seq = ctx.events.back().map(|e| e.observed_at_seq);
        assert_eq!(
            front_seq,
            Some((total_insertions - MAX_TELEMETRY_EVENTS) as u64), // 90,000
            "Oldest non-evicted event must have observed_at_seq = 90000"
        );
        assert_eq!(
            back_seq,
            Some((total_insertions - 1) as u64), // 99,999
            "Newest event must have observed_at_seq = 99999"
        );

        // (c) Constant amortized O(1) performance check across 100,000 insertions.
        // Chunk 2 (evicting 50k times) should take comparable time to Chunk 1 (evicting 40k times).
        let ratio = chunk2_duration.as_secs_f64() / chunk1_duration.as_secs_f64();
        assert!(
            ratio < 2.5,
            "Performance degraded non-linearly: chunk2 ({:?}) vs chunk1 ({:?}), ratio: {:.2}",
            chunk2_duration,
            chunk1_duration,
            ratio
        );

        // Empirical debug latency distribution (20 runs): p50=414ms, p90=426ms, p99=433ms.
        // Threshold set to 1000ms to provide >2x safety headroom against debug build variance on CI runners.
        let total_duration = chunk1_duration + chunk2_duration;
        assert!(
            total_duration < std::time::Duration::from_millis(1000),
            "100,000 telemetry insertions took {:?}, expected <1000ms",
            total_duration
        );

        Ok(())
    }
}

// !SECTION
