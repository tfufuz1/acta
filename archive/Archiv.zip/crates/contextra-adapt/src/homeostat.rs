// FILE-CONTEXT
// ZWECK: P95 retrieval latency feedback-regulated PID controller and hard deadline management (Feature F-08 & P11 requirement).
// INVARIANTEN: k_min >= 50 hard floor (arXiv:2604.01733 T2-RAGBench recall floor); integral windup bounded [-100.0, 100.0].
// STAND: TS:2026-09-11T00:00:00Z

//! PID Controller and Deadline Management for Retrieval Latency Control.
//!
//! NOTE: `RerankPidController` has been consolidated into `crate::PidController`.

use crate::clock::{Clock, SystemClock};
use std::time::Duration;

/// P95 Latency-feedback PID Controller for dynamically tuning candidate pool sizes.
///
/// DEPRECATED: Use [`crate::PidController`] instead.
#[deprecated(
    since = "0.1.0",
    note = "Consolidated into `crate::PidController`. Use `crate::PidController` directly."
)]
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct RerankPidController {
    inner: crate::PidController,
}

#[allow(deprecated)]
impl Default for RerankPidController {
    fn default() -> Self {
        Self::new(150.0, 50, 200, 100)
    }
}

#[allow(deprecated)]
impl RerankPidController {
    /// Creates a new `RerankPidController` with default PID coefficients and configured parameters.
    pub fn new(
        target_p95_latency_ms: f32,
        k_min: usize,
        k_max: usize,
        initial_pool: usize,
    ) -> Self {
        Self {
            inner: crate::PidController::new(
                target_p95_latency_ms,
                k_min,
                k_max,
                Some(initial_pool),
            ),
        }
    }

    /// Accessor for `kp`.
    pub fn kp(&self) -> f32 {
        self.inner.kp
    }

    /// Accessor for `ki`.
    pub fn ki(&self) -> f32 {
        self.inner.ki
    }

    /// Accessor for `kd`.
    pub fn kd(&self) -> f32 {
        self.inner.kd
    }

    /// Accessor for target latency.
    pub fn target_p95_latency_ms(&self) -> f32 {
        self.inner.target_latency_ms
    }

    /// Accessor for current `k_pool`.
    pub fn k_pool(&self) -> usize {
        self.inner
            .current_pool_size
            .unwrap_or(self.inner.min_pool_size)
    }

    /// Accessor for `k_min`.
    pub fn k_min(&self) -> usize {
        self.inner.min_pool_size
    }

    /// Accessor for `k_max`.
    pub fn k_max(&self) -> usize {
        self.inner.max_pool_size
    }

    /// Updates the controller state with observed latency and returns new pool size.
    pub fn update(&mut self, observed_p95_latency_ms: f32) -> usize {
        let dt = Duration::from_millis(100);
        self.inner.update(dt, observed_p95_latency_ms)
    }
}

/// Hard deadline manager for candidate retrieval and Cross-Encoder reranking phases (P11 requirement).
///
/// # Intended Integration Point
/// Evaluated before or during candidate hydration and Cross-Encoder batch inference steps in `Collection::hybrid_search_reranked`.
/// If `deadline_exceeded(started_at)` or `deadline_exceeded_nanos` returns `true`, the search pipeline should immediately break out and return
/// the partially hydrated/reranked candidate results accumulated up to that point rather than blocking indefinitely.
#[derive(Debug, Clone)]
pub struct RerankDeadline<C: ?Sized + Clock = SystemClock> {
    /// Maximum time budget allowed for reranking operations.
    pub budget: Duration,
    clock: std::sync::Arc<C>,
}

impl RerankDeadline<SystemClock> {
    /// Creates a new `RerankDeadline` with the specified duration budget.
    pub fn new(budget: Duration) -> Self {
        Self::new_with_clock(budget, std::sync::Arc::new(SystemClock::new()))
    }
}

impl<C: ?Sized + Clock> RerankDeadline<C> {
    /// Creates a new `RerankDeadline` with explicit `Clock` port injection.
    pub fn new_with_clock(budget: Duration, clock: std::sync::Arc<C>) -> Self {
        Self { budget, clock }
    }

    /// Returns current monotonic timestamp in nanoseconds from injected clock.
    pub fn start_nanos(&self) -> u64 {
        self.clock.monotonic_nanos()
    }

    /// Checks if elapsed nanoseconds since `started_at_nanos` equals or exceeds deadline budget.
    pub fn deadline_exceeded_nanos(&self, started_at_nanos: u64) -> bool {
        let elapsed_nanos = self
            .clock
            .monotonic_nanos()
            .saturating_sub(started_at_nanos);
        elapsed_nanos >= self.budget.as_nanos() as u64
    }

    /// Legacy helper using monotonic_nanos delta based on Instant baseline.
    #[deprecated(since = "0.1.0", note = "Use deadline_exceeded_nanos with start_nanos")]
    pub fn deadline_exceeded(&self, started_at: std::time::Instant) -> bool {
        started_at.elapsed() >= self.budget
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[allow(deprecated)]
    fn test_high_latency_causes_monotonic_decrease_bounded_by_k_min() {
        let mut controller = RerankPidController::new(150.0, 50, 200, 100);
        let mut prev_pool = controller.k_pool();

        // Simulate 10 iterations of severe latency overflow (300ms vs 150ms target)
        for _ in 0..10 {
            let new_pool = controller.update(300.0);
            assert!(
                new_pool <= prev_pool,
                "Pool size must monotonically decrease under high latency: prev={prev_pool}, new={new_pool}"
            );
            assert!(
                new_pool >= 50,
                "Pool size must never fall below hard floor k_min=50: got {new_pool}"
            );
            prev_pool = new_pool;
        }

        assert_eq!(
            controller.k_pool(),
            50,
            "Pool size should settle at hard minimum k_min=50"
        );
    }

    #[test]
    #[allow(deprecated)]
    fn test_low_latency_causes_increase_bounded_by_k_max() {
        let mut controller = RerankPidController::new(150.0, 50, 200, 100);
        let mut prev_pool = controller.k_pool();

        // Simulate 10 iterations of low latency (50ms vs 150ms target)
        for _ in 0..10 {
            let new_pool = controller.update(50.0);
            assert!(
                new_pool >= prev_pool,
                "Pool size must increase under low latency: prev={prev_pool}, new={new_pool}"
            );
            assert!(
                new_pool <= 200,
                "Pool size must never exceed k_max=200: got {new_pool}"
            );
            prev_pool = new_pool;
        }

        assert_eq!(
            controller.k_pool(),
            200,
            "Pool size should settle at maximum k_max=200"
        );
    }

    #[test]
    #[allow(deprecated)]
    fn test_hard_k_min_floor_never_below_50() {
        // Attempt to create a controller with invalid k_min=10 (below scientific floor 50)
        let mut controller = RerankPidController::new(150.0, 10, 200, 100);
        assert_eq!(
            controller.k_min(),
            50,
            "Constructor must enforce hard floor k_min >= 50"
        );

        // Drive latency extremely high
        for _ in 0..50 {
            let pool = controller.update(10_000.0);
            assert!(
                pool >= 50,
                "k_pool must NEVER drop below 50 regardless of control input"
            );
        }
    }

    #[test]
    fn test_rerank_deadline_exceeded() {
        let deadline = RerankDeadline::new(Duration::from_millis(50));
        let start_nanos = deadline.start_nanos();

        assert!(!deadline.deadline_exceeded_nanos(start_nanos));

        std::thread::sleep(Duration::from_millis(60));

        assert!(deadline.deadline_exceeded_nanos(start_nanos));
    }
}
