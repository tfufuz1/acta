//! Kanonische `ModelFingerprint`-Definition für Contextra.
//!
//! # Zweck & Architektur-Rolle: Typen-Fundament
//!
//! Ein Modell-Fingerabdruck sichert die Konsistenz zwischen Vektordatenbank und Inferenz-Engine ab.
//! Wenn Vektoren mit einem Modell (z. B. Embedding-Modell oder SLM) generiert wurden, muss
//! sichergestellt sein, dass bei nachfolgenden Abfragen oder Indexerweiterungen exakt
//! dasselbe Modell und dieselbe Quantisierungsstufe (z. B. Q4_K_M, Q8_0) verwendet wird.

// FILE-CONTEXT
// STAND: 2026-11-10T00:00:00Z
// ZWECK: Canonical ModelFingerprint type definition shared across workspace crates.
// INVARIANTEN: SHA-256 over weight blob concatenated with quantization string; distinct quant tiers yield distinct fingerprints.

//! Canonical `ModelFingerprint` definition for Contextra.
//!
//! # Architektur-Rolle
//! Typen-Fundament (Kern). Keine I/O- oder Asynchron-Abhängigkeiten.
//!
//! # Zweck
//! Eindeutige kryptografische Identifikation von Modellgewichten und Quantisierungsstufen.

use serde::{Deserialize, Serialize};

// ANCHOR[contextra-types:FINGERPRINT-001]
/// Uniquely identifies a model weight file and its quantization tier.
///
/// Dient dazu, Modellgewicht-Dateien und Quantisierungsstufen auf Systemebene
/// unverwechselbar zuzuordnen.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
// ANCHOR[contextra-types:MFP-001]
/// Identifiziert eine Modelldatei und deren Quantisierungsstufe eindeutig.
pub struct ModelFingerprint {
    /// SHA-256 hash digest over model weight blob and quantization tier string.
    pub hash: [u8; 32],
    /// Model identifier or filename (e.g. "llama-3.2-3b-instruct").
    pub model_id: String,
    /// String representation of quantization tier (e.g. "Q4_K_M", "Q8_0", "F16").
    pub quantization: String,
}

impl ModelFingerprint {
    // ANCHOR[contextra-types:FINGERPRINT-002]
    /// Creates a new `ModelFingerprint`.
    ///
    /// # Ablauf
    /// Übernimmt Hash, Modellbezeichner und Quantisierungsstring ohne Nebenwirkungen.
    pub fn new(
        hash: [u8; 32],
        model_id: impl Into<String>,
        quantization: impl Into<String>,
    ) -> Self {
        Self {
            hash,
            model_id: model_id.into(),
            quantization: quantization.into(),
        }
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;

    // NOTE: Prüft Instanziierung und JSON-Roundtrip des ModelFingerprint.
    #[test]
    fn test_model_fingerprint_new_and_serde() {
        let fp = ModelFingerprint::new([0xab; 32], "test-model", "Q4_K_M");
        assert_eq!(fp.hash, [0xab; 32]);
        assert_eq!(fp.model_id, "test-model");
        assert_eq!(fp.quantization, "Q4_K_M");

        let json = serde_json::to_string(&fp).expect("serialization failed");
        let deserialized: ModelFingerprint =
            serde_json::from_str(&json).expect("deserialization failed");
        assert_eq!(fp, deserialized);
    }
}
